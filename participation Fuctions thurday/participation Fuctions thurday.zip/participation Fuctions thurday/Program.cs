﻿//Benjamin Henke
//Collaberated with cale reinking
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace participation_Fuctions_thurday
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("which participation do you want to run? Word Replacer or Fizzbuzz  ");
            string participation = Console.ReadLine().ToLower();
            double Fizzbuzz = 0;

            if (participation == "fizzbuzz")
            {
                
            }
        }
            static void Fizzbuzz(string[] Luckynumber)

            {

                Console.WriteLine("please enter your lucky number here!!");
                string lucky = Console.ReadLine();
                bool number = (Int32.TryParse(lucky, out int LuckyNumber));

                if (number == false)
                {
                    Console.WriteLine($"I am sorry Im unable to run the FizzBuzz process due to {LuckyNumber} not being a valid number");
                }

                else if (LuckyNumber % 3 == 0 && LuckyNumber % 5 == 0)
                {
                    Console.WriteLine($"{LuckyNumber} FizzBuzz");
                }
                else if (LuckyNumber % 3 == 0)
                {
                    Console.WriteLine($"{LuckyNumber} Fizz");
                }
                else if (LuckyNumber % 5 == 0)
                {
                    Console.WriteLine($"{LuckyNumber} Buzz");
                }
                else
                {
                   Console.WriteLine(LuckyNumber);
                }
            {


               string sentence = "Programming today is a race between software engineers striving to build bigger and better idiot-proof programs, and the universe trying to build bigger and better idiots. So far, the universe is winning.";

                Console.WriteLine(sentence);
                Console.WriteLine("what word are looking for in the sentence above");

                string Place = Console.ReadLine();


                Console.WriteLine("what do you want to change it to?");

                string answer = Console.ReadLine();



                if (sentence.Contains(Place))



                {

                    string newsent = sentence.Replace(Place, answer);

                    Console.WriteLine(newsent);



                }

                else

                {

                    Console.WriteLine($"sorry i could not find your word {answer}");



                    for (int i = 0; i > answer.Length - 1; i--)

                    {

                        Console.WriteLine(answer[i]);

                    }











                }











                Console.ReadKey();


                 }
          

            }
    }
}
