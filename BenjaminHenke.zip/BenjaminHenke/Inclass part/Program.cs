﻿//Benjamin Henke
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inclass_part
{
    class Program
    {
        static void Main(string[] args)
        {
            int coin;// this will hold my random int numbers.

            string userInput;// This will hold all my user input/ answers.




            Console.WriteLine("Hello, Pick Heads or Tails:");
            string UserInputAsString = console.readline();
            int UserInput;

            if (UserInputAsString == "Heads')
            {
                UserInput =1;
            }
            else
            { UserInput = 2;
                 
            random read = new Random();

                int randomNumber = rad.next(0, 2);

                if (UserInputAsString == 'Trails')
                    Console.ReadKey();

        
        }
    }
}
